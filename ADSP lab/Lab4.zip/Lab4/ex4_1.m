%clc; clear all; close all;

 n = -1.5:0.00001:1.5;
 x = n;
 w = 5;
 
 y1 = twosquant(n,w,'r','s');
 y2 = twosquant(n,w,'t','s');
 y3 = twosquant(n,w,'r','o');
 y4 = twosquant(n,w,'t','o');
 e1 = x - y1;
 e2 = x - y2;
 e3 = x - y3;
 e4 = x - y4;
 figure(2);
 subplot(2,2,1); plot(n,y1,n,x,n,e1,'Linewidth',1.5); 
 title('Rounding and Saturation'); legend('Output','Input','Error');
 subplot(2,2,2); plot(n,y2,n,x,n,e2,'Linewidth',1.5); 
 title('Truncation and Saturation'); legend('Output','Input','Error');
 subplot(2,2,3); plot(n,y3,n,x,n,e3,'Linewidth',1.5); 
 title('Rounding and Overflow'); legend('Output','Input','Error');
 subplot(2,2,4); plot(n,y4,n,x,n,e4,'Linewidth',1.5); 
 title('Truncation and Overflow'); legend('Output','Input','Error');
 