clc; clear all; close all;

theta = 0:2*pi/100:2*pi;
r1 = cos(theta); r2 = sin(theta); 
figure(2);
plot(r1,r2,'b.','Linewidth',1.5); hold on;
a = [1 0 0];
for k = -1:0.1:1
    for l = -1:0.1:1
        b = [1,-k,l];
        Hd = tf(a,b);
%          Hd = dfilt.df2(a,b);
%          Hd.Arithmetic = 'fixed';
%          Hd.Roundmode = 'floor';
%          Hd.OverflowMode = 'wrap';
%          Hd.CoeffWordLength = 4;
        P = pole(Hd);
        plot(real(P),imag(P),'r.'); hold on;
    end
end
hold off;